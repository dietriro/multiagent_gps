#include "gps_rover_pkg/roverplugin.h"
#include "gps_rover_pkg/positioncontroller.h"
#include "gps_rover_pkg/trialcontroller.h"
#include "gps_rover_pkg/encodersensor.h"
#include "gps_rover_pkg/util.h"

namespace gps_control {

// Plugin constructor.
GPSROVERPlugin::GPSROVERPlugin()
{
    // Some basic variable initialization.
    controller_counter_ = 0;
    controller_step_length_ = 50;
}

// Destructor.
GPSROVERPlugin::~GPSROVERPlugin()
{
    // Nothing to do here, since all instance variables are destructed automatically.
}

// Initialize the object and store the robot state.
bool GPSROVERPlugin::init(ros::NodeHandle& n)
{

    // Initialize ROS subscribers/publishers, sensors, and position controllers.
    // Note that this must be done after the FK solvers are created, because the sensors
    // will ask to use these FK solvers!
    initialize(n);

    // Tell the PR2 controller manager that we initialized everything successfully.
    return true;
}

// This is called by the controller manager before starting the controller.
void GPSROVERPlugin::starting()
{
    // Get current time.
    //last_update_time_ = robot_->getTime();
    controller_counter_ = 0;

    // Reset all the sensors. This is important for sensors that try to keep
    // track of the previous state somehow.
    //for (int sensor = 0; sensor < TotalSensorTypes; sensor++)
    for (int sensor = 0; sensor < 1; sensor++)
    {
        sensors_[sensor]->reset(this,last_update_time_);
    }

    // Reset trial controller, if any.
    if (trial_controller_ != NULL) trial_controller_->reset(last_update_time_);
}

// This is called by the controller manager before stopping the controller.
void GPSROVERPlugin::stopping()
{
    // Nothing to do here.
}

// This is the main update function called by the realtime thread when the controller is running.
void GPSROVERPlugin::update()
{
    // Get current time.
    //last_update_time_ = robot_->getTime();

    // Check if this is a controller step based on the current controller frequency.
    controller_counter_++;
    if (controller_counter_ >= controller_step_length_) controller_counter_ = 0;
    bool is_controller_step = (controller_counter_ == 0);

    // Update the sensors and fill in the current step sample.
    update_sensors(last_update_time_,is_controller_step);

    // Update the controllers.
    update_controllers(last_update_time_,is_controller_step);

}

// Get current time.
ros::Time GPSROVERPlugin::get_current_time() const
{
    return last_update_time_;
}

// Get current encoder readings (robot-dependent).
void GPSROVERPlugin::get_joint_encoder_readings(Eigen::VectorXd &angles, gps::ActuatorType arm) const
{

}

}

// Register controller to pluginlib
PLUGINLIB_EXPORT_CLASS(gps_control::GPSROVERPlugin,
						controller_interface::Controller)

